version = 7
my_date = "2017-01-07"

varves = read.csv('data/varves.csv', stringsAsFactors=FALSE)
vids   = varves$id
states_vs = varves$state
